class Todo < ApplicationRecord
    enum status: { incomplete: 0, complete: 1 }
  end
  
class ChangeStatusDefaultOnTodos < ActiveRecord::Migration[7.2]
    def change
      change_column_default :todos, :status, from: nil, to: 0
    end
  end